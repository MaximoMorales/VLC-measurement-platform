clc 
clear all
close all


P = readmatrix('A0_RAW_datos_adquisicion_posX000.csv');


Vmedio = mean(P.')
[Nmedidas, Tiempo] = size(P)

for n = 1:Nmedidas
    PosUp = find(P(n,:) > 1.1*Vmedio(n));
    PosDown = find(P(n,:) < 0.9*Vmedio(n));
    Vup = mean(P(n,PosUp))*5/(2^12 - 1);
    Vdown = mean(P(n,PosDown))*5/(2^12 - 1);
    h(n) = (Vup - Vdown)/(5*10^2)
end



