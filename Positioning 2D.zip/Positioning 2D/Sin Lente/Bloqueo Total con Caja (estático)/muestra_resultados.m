clc
clear all
close all

load('matrices.mat')

figure(1)
t = linspace(0, 40, length(sum(A0_X000, 2)))
plot(t, A0_X000)


figure(2)
t = linspace(0, 40, length(sum(A0_X200, 2)))
plot(t, A0_X200)

figure(3)
t = linspace(0, 40, length(sum(A0_X400, 2)))
plot(t, A0_X400)

figure(4)
t = linspace(0, 40, length(sum(A0_X600, 2)))
plot(t, A0_X600)

figure(5)
t = linspace(0, 40, length(sum(A0_X800, 2)))
plot(t,A0_X800)

figure(6)
t = linspace(0, 40, length(sum(A0_X1000, 2)))
plot(t,A0_X1000)

